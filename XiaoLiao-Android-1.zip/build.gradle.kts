plugins {
    base
}
