package com.example.llama

import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.arm.aichat.AiChat
import com.arm.aichat.InferenceEngine
import com.arm.aichat.gguf.GgufMetadataReader
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.onCompletion
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

class MainActivity : AppCompatActivity() {
    private lateinit var status: TextView
    private lateinit var messagesRv: RecyclerView
    private lateinit var input: EditText
    private lateinit var send: Button
    private lateinit var nativeBtn: Button
    private lateinit var saveBtn: Button
    private lateinit var engine: InferenceEngine
    private var ready=false
    private var job: Job?=null
    private val messages= mutableListOf<Message>()
    private val adapter=MessageAdapter(messages)
    private val assistant=StringBuilder()
    private var lastUser=""
    private var lastAssistant=""

    private val prefs by lazy { getSharedPreferences("xiaoliao", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); enableEdgeToEdge(); setContentView(R.layout.activity_main)
        status=findViewById(R.id.status); messagesRv=findViewById(R.id.messages); input=findViewById(R.id.user_input)
        send=findViewById(R.id.send); nativeBtn=findViewById(R.id.native_btn); saveBtn=findViewById(R.id.save_btn)
        messagesRv.layoutManager=LinearLayoutManager(this).apply{stackFromEnd=true}; messagesRv.adapter=adapter
        restoreHistory()
        lifecycleScope.launch(Dispatchers.Default){ engine=AiChat.getInferenceEngine(applicationContext) }
        send.setOnClickListener { if(ready) chat(input.text.toString()) else picker.launch(arrayOf("*/*")) }
        nativeBtn.setOnClickListener {
            if(!ready) Toast.makeText(this,"먼저 GGUF 모델을 선택하세요",Toast.LENGTH_SHORT).show()
            else if(lastUser.isNotBlank()) generate(nativePrompt(lastUser), true)
        }
        saveBtn.setOnClickListener {
            if(lastAssistant.isNotBlank()) {
                val s=prefs.getStringSet("saved", emptySet())!!.toMutableSet(); s.add(lastAssistant.take(300))
                prefs.edit().putStringSet("saved",s).apply()
                Toast.makeText(this,"표현 저장됨",Toast.LENGTH_SHORT).show()
            }
        }
    }

    private val picker=registerForActivityResult(ActivityResultContracts.OpenDocument()){ uri-> uri?.let{load(it)} }

    private fun load(uri:Uri){
        send.isEnabled=false; status.text="GGUF 확인 중…"
        lifecycleScope.launch(Dispatchers.IO){
            val meta=contentResolver.openInputStream(uri)?.use{GgufMetadataReader.create().readStructuredMetadata(it)}
                ?: return@launch
            val dir=File(filesDir,"models").apply{mkdirs()}
            val file=File(dir,"xiaoliao.gguf")
            contentResolver.openInputStream(uri)!!.use{src-> FileOutputStream(file).use{dst->src.copyTo(dst)}}
            withContext(Dispatchers.Main){status.text="모델 로딩 중…"}
            engine.loadModel(file.path)
            withContext(Dispatchers.Main){
                ready=true; send.isEnabled=true; input.isEnabled=true; send.text="전송"
                status.text="XiaoLiao · 오프라인 · ${meta.basic.name ?: "GGUF"}"
            }
        }
    }

    private fun chat(raw:String){
        val s=raw.trim(); if(s.isEmpty())return
        input.text.clear(); lastUser=s
        add(Message(UUID.randomUUID().toString(),s,true))
        generate(chatPrompt(s),false)
    }

    private fun generate(prompt:String, localization:Boolean){
        input.isEnabled=false; send.isEnabled=false; assistant.clear()
        add(Message(UUID.randomUUID().toString(),"",false))
        job=lifecycleScope.launch(Dispatchers.Default){
            engine.sendUserPrompt(prompt).onCompletion{
                withContext(Dispatchers.Main){input.isEnabled=true;send.isEnabled=true; persistHistory()}
            }.collect{tok->
                withContext(Dispatchers.Main){
                    assistant.append(tok); lastAssistant=assistant.toString()
                    messages[messages.lastIndex]=messages.last().copy(content=lastAssistant)
                    adapter.notifyItemChanged(messages.lastIndex); messagesRv.scrollToPosition(messages.lastIndex)
                }
            }
        }
    }

    private fun chatPrompt(user:String):String {
        val saved=prefs.getStringSet("saved", emptySet())!!.take(5).joinToString("、")
        return """你是在中国大陆长大的年轻朋友，正在微信式一对一聊天。
目标是自然聊天，不要像老师，不要主动纠错，不要解释语法。
使用当代中国大陆日常口语和聊天表达；简短、自然、符合上下文。
不要为了“像中国人”硬塞网络梗、方言或过时流行语。
除非用户要求，否则主要用简体中文回复。
用户正在学习并喜欢这些表达：$saved
合适时可以自然地再次使用其中一两个，不合适就不要强塞。
不要输出思考过程，只输出要发给对方的聊天内容。

用户：$user"""
    }

    private fun nativePrompt(user:String)= """把下面这句话改成中国大陆年轻人在一对一聊天里更自然会说的话。
给 2~3 个版本，按“最自然 / 更随意 / 另一种语气”区分。
然后用很短的韩语说明关键表达和语气差异。
不要长篇讲语法，不要输出思考过程。
原句：$user"""

    private fun add(m:Message){messages.add(m);adapter.notifyItemInserted(messages.lastIndex);messagesRv.scrollToPosition(messages.lastIndex);persistHistory()}

    private fun persistHistory(){
        val a=JSONArray(); messages.takeLast(80).forEach{m->a.put(JSONObject().put("c",m.content).put("u",m.isUser))}
        prefs.edit().putString("history",a.toString()).apply()
    }
    private fun restoreHistory(){
        runCatching{
            val a=JSONArray(prefs.getString("history","[]")); for(i in 0 until a.length()){
                val o=a.getJSONObject(i); messages.add(Message(UUID.randomUUID().toString(),o.getString("c"),o.getBoolean("u")))
            }
            adapter.notifyDataSetChanged()
        }
    }
    override fun onStop(){job?.cancel();super.onStop()}
    override fun onDestroy(){if(::engine.isInitialized)engine.destroy();super.onDestroy()}
}