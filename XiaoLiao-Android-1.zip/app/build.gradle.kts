plugins {
    base
}

val upstreamDir = layout.buildDirectory.dir("llama-upstream")
val outputDir = layout.buildDirectory.dir("outputs/apk/debug")

tasks.register<Exec>("assembleDebug") {
    val repo = upstreamDir.get().asFile
    val out = outputDir.get().asFile
    doFirst {
        repo.parentFile.mkdirs()
        out.mkdirs()
        if (repo.exists()) repo.deleteRecursively()
    }
    commandLine("bash", "-lc", """
        set -euo pipefail
        git clone --depth 1 https://github.com/ggml-org/llama.cpp.git '${repo.absolutePath}'
        cp '${rootProject.projectDir.absolutePath}/patch/MainActivity.kt' '${repo.absolutePath}/examples/llama.android/app/src/main/java/com/example/llama/MainActivity.kt'
        cp '${rootProject.projectDir.absolutePath}/patch/activity_main.xml' '${repo.absolutePath}/examples/llama.android/app/src/main/res/layout/activity_main.xml'
        cd '${repo.absolutePath}/examples/llama.android'
        chmod +x gradlew
        ./gradlew :app:assembleDebug --no-daemon --stacktrace
        cp app/build/outputs/apk/debug/app-debug.apk '${out.absolutePath}/XiaoLiao-debug.apk'
        unzip -l '${out.absolutePath}/XiaoLiao-debug.apk' > '${out.absolutePath}/apk-contents.txt'
        grep -Eq 'lib/arm64-v8a/.*\.so' '${out.absolutePath}/apk-contents.txt'
    """.trimIndent())
}
