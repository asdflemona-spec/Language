XiaoLiao ZIP-UPLOAD edition

이 ZIP 파일 이름은 반드시 XiaoLiao-Android.zip 으로 유지하세요.
GitHub 저장소 루트에 ZIP 자체만 업로드하면 기존 build-apk.yml이:
1) ZIP 압축 해제
2) settings.gradle.kts 발견
3) gradle :app:assembleDebug 실행
4) 공식 llama.cpp Android 소스 다운로드
5) XiaoLiao 기능 주입
6) 실제 native inference APK 생성
7) APK artifact 업로드
를 수행합니다.

ZIP을 풀어서 GitHub에 올릴 필요 없습니다.
