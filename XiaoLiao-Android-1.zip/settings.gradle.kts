rootProject.name = "XiaoLiaoZipBootstrap"
include(":app")
