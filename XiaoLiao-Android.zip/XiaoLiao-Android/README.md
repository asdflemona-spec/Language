# XiaoLiao Android
개인용 중국어 현지 채팅 앱의 Android/GitHub Actions 베이스.

## GitHub에서 APK 만들기
1. 이 ZIP을 풀고 **내용물 전체**를 새 GitHub 저장소 루트에 업로드합니다. ZIP 파일 자체만 올리면 Actions가 실행되지 않습니다.
2. 기본 브랜치를 `main`으로 둡니다.
3. `Actions` → `Build APK` → `Run workflow` 또는 main에 push합니다.
4. 완료 후 workflow의 `Artifacts`에서 `XiaoLiao-debug-apk`를 받습니다.

## 현재 단계
v0.1은 Android/Gradle/GitHub Actions/APK 및 Android Storage Access Framework(GGUF 선택) 파이프라인을 먼저 검증하는 베이스입니다.
**아직 llama.cpp 추론 코드는 포함하지 않았습니다.** UI가 추론되는 것처럼 위장하지 않습니다.

다음 고정 단계는 공식 llama.cpp Android 바인딩을 pin하여 실제 GGUF 추론을 연결하는 것입니다. llama.cpp를 master 추적하지 않고 검증된 릴리스/커밋에 고정합니다.
