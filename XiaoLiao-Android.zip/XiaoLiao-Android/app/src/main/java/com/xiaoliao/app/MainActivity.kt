package com.xiaoliao.app
import android.app.*
import android.os.Bundle
import android.content.Intent
import android.provider.Settings
import android.graphics.Typeface
import android.view.*
import android.widget.*
class MainActivity: Activity() {
 private lateinit var log: TextView
 override fun onCreate(b: Bundle?) { super.onCreate(b)
  val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL; setPadding(32,32,32,24)}
  val title=TextView(this).apply{text="小聊 · 本地中文聊天"; textSize=24f; setTypeface(null,Typeface.BOLD)}
  val status=TextView(this).apply{text="오프라인 개인용 · S24 기준\n모델: 아직 선택되지 않음"; textSize=14f; setPadding(0,12,0,20)}
  val pick=Button(this).apply{text="GGUF 모델 선택"; setOnClickListener{startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT).apply{type="*/*"; addCategory(Intent.CATEGORY_OPENABLE)},7)}}
  log=TextView(this).apply{text="\n모델을 선택하면 이 위치에 로컬 추론 엔진이 연결됩니다.\n\n⚠ 이 저장소의 v0.1은 GitHub→APK 파이프라인 검증용입니다. llama.cpp 런타임은 다음 고정 단계에서 연결합니다."; textSize=16f}
  root.addView(title);root.addView(status);root.addView(pick);root.addView(log,LinearLayout.LayoutParams(-1,0,1f));setContentView(root)
 }
 override fun onActivityResult(r:Int,c:Int,d:Intent?){super.onActivityResult(r,c,d);if(r==7&&c==RESULT_OK){val u=d?.data?:return;contentResolver.takePersistableUriPermission(u,Intent.FLAG_GRANT_READ_URI_PERMISSION);log.text="선택됨: $u\n\nGGUF 파일 접근 권한 저장 완료."}}
}
