# XiaoLiao One-Shot
압축을 풀어 저장소 루트에 올리세요. ZIP 자체를 올리지 마세요.
기존 `.github/workflows/build-apk.yml`은 이 패키지 것으로 교체합니다.

포함:
- 공식 llama.cpp Android native inference
- GGUF 선택/앱 전용 저장소 복사/실제 모델 로드
- 중국 본토 일상 채팅 프롬프트
- 현지인이면? 2~3개 자연스러운 표현 + 한국어 설명
- 표현 저장 및 이후 프롬프트 재노출
- 최근 대화 로컬 저장
- 서버/API/로그인 없음

주의: 모델 GGUF 자체는 용량 때문에 포함하지 않습니다.
Qwen3 GGUF를 휴대폰에 별도로 준비한 뒤 앱에서 최초 1회 선택합니다.
