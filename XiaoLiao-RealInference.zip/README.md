# XiaoLiao – real llama.cpp inference baseline

이 저장소는 이전의 7KB Android 뼈대 앱을 사용하지 않습니다.

GitHub Actions가 공식 ggml-org/llama.cpp 저장소를 받아
`examples/llama.android`의 실제 Android inference 앱을 빌드합니다.

## 이 APK에서 확인할 것

1. Actions의 `Build XiaoLiao Real Inference APK`가 성공한다.
2. Artifacts에서 `XiaoLiao-real-llamacpp-baseline`을 받는다.
3. Galaxy S24에 APK를 설치한다.
4. 앱에서 GGUF 모델을 선택한다.
5. 모델이 실제로 로드되고 프롬프트에 토큰을 생성하는지 확인한다.

이 단계의 목적은 'UI만 있는 가짜 앱'이 아니라 실제 llama.cpp JNI/NDK 추론 경로를
휴대폰에서 먼저 검증하는 것입니다.

## 아직 XiaoLiao 전용으로 구현하지 않은 것

- XiaoLiao 전용 채팅 UI
- `현지인이면?`
- 표현 저장/재노출
- Room 기반 개인화
- Qwen3 전용 프롬프트/비-thinking 설정

위 기능은 실제 inference baseline이 S24에서 동작하는 것이 확인된 뒤
공식 Android app/lib 구조를 유지하면서 추가하는 다음 단계입니다.

## 권한

이 부트스트랩 프로젝트 자체는 GitHub 계정/서버/API 키를 요구하지 않습니다.
모델 파일 선택은 Android의 문서 선택 방식을 사용하는 공식 예제를 기반으로 합니다.
