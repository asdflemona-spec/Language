rootProject.name="XiaoLiaoBootstrap"
include(":app")
