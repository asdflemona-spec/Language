package com.example.llama

import android.net.Uri
import android.os.Bundle
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.arm.aichat.AiChat
import com.arm.aichat.InferenceEngine
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.onCompletion
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

class MainActivity : AppCompatActivity() {
    private lateinit var engine: InferenceEngine
    private lateinit var status: TextView
    private lateinit var input: EditText
    private lateinit var action: Button
    private lateinit var rv: RecyclerView
    private val msgs=mutableListOf<Message>()
    private val adapter=MessageAdapter(msgs)
    private var ready=false
    private var generation:Job?=null
    private val prefs by lazy { getSharedPreferences("xl", MODE_PRIVATE) }

    override fun onCreate(b:Bundle?){
        super.onCreate(b); setContentView(R.layout.activity_main)
        status=findViewById(R.id.status); input=findViewById(R.id.input); action=findViewById(R.id.action); rv=findViewById(R.id.messages)
        rv.layoutManager=LinearLayoutManager(this).apply{stackFromEnd=true}; rv.adapter=adapter
        lifecycleScope.launch(Dispatchers.Default){
            engine=AiChat.getInferenceEngine(applicationContext)
            val saved=prefs.getString("model",null)
            if(saved!=null && File(saved).exists()) load(File(saved), false)
            else withContext(Dispatchers.Main){status.text="Qwen3 GGUF를 한 번 선택하세요"}
        }
        action.setOnClickListener {
            if(!ready) picker.launch(arrayOf("*/*")) else send()
        }
    }

    private val picker=registerForActivityResult(ActivityResultContracts.OpenDocument()){u->if(u!=null) importModel(u)}

    private fun importModel(uri:Uri){
        action.isEnabled=false; status.text="모델 복사 중… (2.5GB라 시간이 걸릴 수 있음)"
        lifecycleScope.launch(Dispatchers.IO){
            try{
                val dir=File(filesDir,"models").apply{mkdirs()}
                val f=File(dir,"qwen3.gguf")
                contentResolver.openInputStream(uri)!!.use{src->FileOutputStream(f).use{dst->src.copyTo(dst)}}
                prefs.edit().putString("model",f.absolutePath).apply()
                load(f,true)
            }catch(e:Exception){withContext(Dispatchers.Main){status.text="실패: ${e.message}";action.isEnabled=true}}
        }
    }

    private suspend fun load(f:File, first:Boolean)=withContext(Dispatchers.IO){
        try{
            withContext(Dispatchers.Main){status.text="Qwen3 실제 로딩 중…"}
            engine.loadModel(f.absolutePath)
            engine.setSystemPrompt("""你是小聊。请像中国大陆年轻朋友一样自然聊天。
使用简体中文、日常口语、短句。不要主动纠正用户，不要像教科书。
不要输出思考过程。除非用户明确要求，否则直接聊天。""")
            withContext(Dispatchers.Main){
                ready=true; input.isEnabled=true; action.isEnabled=true; action.text="전송"
                status.text="Qwen3 준비 완료 · 오프라인"
                if(first) Toast.makeText(this@MainActivity,"이제부터 모델 선택 없이 사용합니다",Toast.LENGTH_LONG).show()
            }
        }catch(e:Exception){withContext(Dispatchers.Main){status.text="모델 로드 실패: ${e.message}";action.isEnabled=true}}
    }

    private fun send(){
        val q=input.text.toString().trim(); if(q.isEmpty())return
        input.text.clear(); add(Message(UUID.randomUUID().toString(),q,true))
        val sb=StringBuilder(); add(Message(UUID.randomUUID().toString(),"",false))
        input.isEnabled=false; action.isEnabled=false
        generation=lifecycleScope.launch(Dispatchers.Default){
            engine.sendUserPrompt(q,512).onCompletion{
                withContext(Dispatchers.Main){input.isEnabled=true;action.isEnabled=true}
            }.collect{t->withContext(Dispatchers.Main){
                sb.append(t); msgs[msgs.lastIndex]=msgs.last().copy(content=sb.toString())
                adapter.notifyItemChanged(msgs.lastIndex);rv.scrollToPosition(msgs.lastIndex)
            }}
        }
    }
    private fun add(m:Message){msgs.add(m);adapter.notifyItemInserted(msgs.lastIndex);rv.scrollToPosition(msgs.lastIndex)}
    override fun onStop(){generation?.cancel();super.onStop()}
    override fun onDestroy(){if(::engine.isInitialized)engine.destroy();super.onDestroy()}
}