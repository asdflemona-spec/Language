plugins { base }

val upstream = layout.buildDirectory.dir("llama.cpp")
val apkOut = layout.buildDirectory.dir("outputs/apk/debug")

tasks.register<Exec>("assembleDebug") {
    doFirst {
        upstream.get().asFile.deleteRecursively()
        apkOut.get().asFile.mkdirs()
    }
    commandLine("bash", "-lc", """
      set -euo pipefail
      git clone --depth 1 https://github.com/ggml-org/llama.cpp.git '${upstream.get().asFile.absolutePath}'
      cp '${rootProject.projectDir}/patch/MainActivity.kt' '${upstream.get().asFile.absolutePath}/examples/llama.android/app/src/main/java/com/example/llama/MainActivity.kt'
      cp '${rootProject.projectDir}/patch/activity_main.xml' '${upstream.get().asFile.absolutePath}/examples/llama.android/app/src/main/res/layout/activity_main.xml'
      cd '${upstream.get().asFile.absolutePath}/examples/llama.android'
      chmod +x gradlew
      ./gradlew :app:assembleDebug --no-daemon --stacktrace
      cp app/build/outputs/apk/debug/app-debug.apk '${apkOut.get().asFile.absolutePath}/XiaoLiao-REAL-debug.apk'
      unzip -l '${apkOut.get().asFile.absolutePath}/XiaoLiao-REAL-debug.apk' > '${apkOut.get().asFile.absolutePath}/contents.txt'
      grep -Eq 'lib/arm64-v8a/.*\.so' '${apkOut.get().asFile.absolutePath}/contents.txt'
    """.trimIndent())
}
