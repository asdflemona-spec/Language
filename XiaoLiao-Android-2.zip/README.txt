이 파일은 기존 GitHub 빌드 workflow용입니다.
압축을 풀지 말고 XiaoLiao-Android.zip 이름 그대로 저장소 루트에 업로드하세요.
목표: Qwen3 GGUF 실제 loadModel -> setSystemPrompt -> sendUserPrompt -> streaming 출력.
최초 한 번 GGUF를 앱 내부로 복사한 뒤 다음 실행부터 자동 로딩합니다.
